//Przykład 3_58
document.write(tab3[2])