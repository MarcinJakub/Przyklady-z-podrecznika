//Przykład 3.6
var i = 30;
document.write("Zmienna i ma wartość "+ i +"<br>");