//Przykład 3.73
setTimeout("showtime()",1000);