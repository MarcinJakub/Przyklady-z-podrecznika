//Przykład 3.71
window.document.links