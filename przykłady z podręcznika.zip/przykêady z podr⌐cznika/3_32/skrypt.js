//Przykład 3.32
function lista_arg() {
    return arguments;
}