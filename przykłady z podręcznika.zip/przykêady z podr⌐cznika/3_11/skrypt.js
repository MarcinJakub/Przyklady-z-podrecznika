//Przykład 3.11
var a = 12;
var b = 0o37;
var c = 0xACB;
var d = 0.12e-2;