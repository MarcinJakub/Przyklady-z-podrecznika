//Przykład 3.5
document.write(201);